import os
import time
import unicodedata
import uuid
from datetime import datetime, timedelta, timezone

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build


# CONFIGURAÇÕES
ID_DA_PLANILHA = "1aLQwFlp96QTDerap6zcC04q6p3BVqb1OFGCtNsdY52w"

# Informe o nome da aba ou deixe None para usar a primeira.
NOME_DA_ABA = None

FUSO_HORARIO = "America/Sao_Paulo"

SCOPES = [
    "https://www.googleapis.com/auth/calendar.events",
    "https://www.googleapis.com/auth/spreadsheets",
]

PASTA_DO_CODIGO = os.path.dirname(os.path.abspath(__file__))
ARQUIVO_TOKEN = os.path.join(PASTA_DO_CODIGO, "token.json")
ARQUIVO_CREDENCIAIS = os.path.join(
    PASTA_DO_CODIGO, "credentials.json"
)

CAMPOS_DA_PLANILHA = {
    "nome": {"nome", "nomecandidato", "nomedocandidato"},
    "vaga": {"vaga", "cargo"},
    "data": {"data", "datadaentrevista"},
    "hora": {"hora", "horario", "horadaentrevista"},
    "email": {"email", "emailcandidato", "emaildocandidato"},
    "status": {"status", "statusdaentrevista"},
}


def normalizar_texto(texto):
    """Remove acentos, espaços e pontuação para comparar cabeçalhos."""
    texto = unicodedata.normalize("NFKD", str(texto))
    return "".join(
        caractere.lower()
        for caractere in texto
        if caractere.isalnum()
    )


def autenticar_google():
    """Autentica no Google e retorna as credenciais."""
    credenciais = None

    if os.path.exists(ARQUIVO_TOKEN):
        credenciais = Credentials.from_authorized_user_file(
            ARQUIVO_TOKEN, SCOPES
        )

    if (
        credenciais
        and credenciais.expired
        and credenciais.refresh_token
    ):
        try:
            credenciais.refresh(Request())
        except RefreshError as erro:
            if "invalid_grant" not in str(erro):
                raise

            credenciais = None

    if not credenciais or not credenciais.valid:
        if not os.path.exists(ARQUIVO_CREDENCIAIS):
            raise FileNotFoundError(
                "Coloque credentials.json na mesma pasta do código."
            )

        fluxo = InstalledAppFlow.from_client_secrets_file(
            ARQUIVO_CREDENCIAIS, SCOPES
        )
        credenciais = fluxo.run_local_server(port=0)

    with open(ARQUIVO_TOKEN, "w", encoding="utf-8") as arquivo:
        arquivo.write(credenciais.to_json())

    return credenciais


def preparar_planilha(credenciais):
    """Localiza a aba e verifica os cabeçalhos antes de agendar."""
    servico = build("sheets", "v4", credentials=credenciais)

    metadados = servico.spreadsheets().get(
        spreadsheetId=ID_DA_PLANILHA,
        fields="sheets(properties(sheetId,title))",
    ).execute()

    abas = metadados.get("sheets", [])

    if not abas:
        raise ValueError("A planilha não possui abas.")

    if NOME_DA_ABA is None:
        aba = abas[0]["properties"]
    else:
        aba = next(
            (
                item["properties"]
                for item in abas
                if item["properties"]["title"] == NOME_DA_ABA
            ),
            None,
        )

        if aba is None:
            raise ValueError(
                f"A aba '{NOME_DA_ABA}' não foi encontrada."
            )

    titulo = aba["title"].replace("'", "''")
    intervalo = f"'{titulo}'!A1:1"

    resposta = servico.spreadsheets().values().get(
        spreadsheetId=ID_DA_PLANILHA,
        range=intervalo,
    ).execute()

    linhas = resposta.get("values", [])

    if not linhas:
        raise ValueError(
            "Preencha a primeira linha com: "
            "Nome, Vaga, Data, Hora, Email e Status."
        )

    cabecalhos = linhas[0]
    indices = {}

    for indice, cabecalho in enumerate(cabecalhos):
        texto = normalizar_texto(cabecalho)

        for campo, alternativas in CAMPOS_DA_PLANILHA.items():
            if texto in alternativas:
                if campo in indices:
                    raise ValueError(
                        f"Há mais de uma coluna para o campo '{campo}'."
                    )

                indices[campo] = indice
                break

    faltantes = set(CAMPOS_DA_PLANILHA) - set(indices)

    if faltantes:
        raise ValueError(
            "Cabeçalhos ausentes: " + ", ".join(sorted(faltantes))
        )

    return servico, titulo, cabecalhos, indices


def agendar_entrevista_com_meet(
    credenciais,
    nome_candidato,
    email_candidato,
    vaga,
    data_hora_inicio,
    data_hora_fim,
):
    """Cria o evento e consulta o link do Meet."""
    if data_hora_fim <= data_hora_inicio:
        raise ValueError("O término deve ser posterior ao início.")

    servico = build("calendar", "v3", credentials=credenciais)

    evento = {
        "summary": f"Entrevista: {nome_candidato} — {vaga}",
        "description": (
            "Entrevista de alinhamento com o time de People."
        ),
        "start": {
            "dateTime": data_hora_inicio.isoformat(),
            "timeZone": FUSO_HORARIO,
        },
        "end": {
            "dateTime": data_hora_fim.isoformat(),
            "timeZone": FUSO_HORARIO,
        },
        "attendees": [{"email": email_candidato}],
        "conferenceData": {
            "createRequest": {
                "requestId": str(uuid.uuid4()),
                "conferenceSolutionKey": {
                    "type": "hangoutsMeet",
                },
            },
        },
    }

    evento_criado = servico.events().insert(
        calendarId="primary",
        body=evento,
        conferenceDataVersion=1,
        sendUpdates="all",
    ).execute()

    # O Google pode levar alguns segundos para gerar o link.
    for tentativa in range(6):
        link_meet = evento_criado.get("hangoutLink")

        if link_meet:
            return evento_criado, link_meet

        status = (
            evento_criado.get("conferenceData", {})
            .get("createRequest", {})
            .get("status", {})
            .get("statusCode")
        )

        if status == "failure" or tentativa == 5:
            break

        time.sleep(2)

        evento_criado = servico.events().get(
            calendarId="primary",
            eventId=evento_criado["id"],
        ).execute()

    return evento_criado, None


def registrar_candidato_na_planilha(
    servico,
    titulo_aba,
    cabecalhos,
    indices,
    nome,
    email,
    vaga,
    status,
    data_hora_inicio=None,
):
    """Adiciona o candidato respeitando a ordem dos cabeçalhos."""
    dados = {
        "nome": nome,
        "vaga": vaga,
        "data": (
            data_hora_inicio.strftime("%d/%m/%Y")
            if data_hora_inicio
            else ""
        ),
        "hora": (
            data_hora_inicio.strftime("%H:%M")
            if data_hora_inicio
            else ""
        ),
        "email": email,
        "status": status,
    }

    linha = [""] * len(cabecalhos)

    for campo, valor in dados.items():
        linha[indices[campo]] = valor

    return servico.spreadsheets().values().append(
        spreadsheetId=ID_DA_PLANILHA,
        range=f"'{titulo_aba}'!A1",
        valueInputOption="RAW",
        insertDataOption="INSERT_ROWS",
        body={"values": [linha]},
    ).execute()


def listar_entrevistas():
    """Retorna entrevistas registradas na planilha, da mais recente à mais antiga."""
    credenciais = autenticar_google()
    servico, titulo, cabecalhos, indices = preparar_planilha(credenciais)
    ultima_coluna = ""
    numero_coluna = len(cabecalhos)
    while numero_coluna:
        numero_coluna, resto = divmod(numero_coluna - 1, 26)
        ultima_coluna = chr(65 + resto) + ultima_coluna

    resposta = servico.spreadsheets().values().get(
        spreadsheetId=ID_DA_PLANILHA,
        range=f"'{titulo}'!A2:{ultima_coluna}",
    ).execute()

    entrevistas = []
    for linha in resposta.get("values", []):
        valores = {
            campo: linha[indice] if indice < len(linha) else ""
            for campo, indice in indices.items()
        }
        data = valores["data"].strip()
        hora = valores["hora"].strip()
        if not data or not hora:
            continue

        data_hora = datetime.strptime(
            f"{data} {hora}", "%d/%m/%Y %H:%M"
        )

        entrevistas.append(
            {
                "Data e hora": f"{data} às {hora}",
                "Candidato": valores["nome"],
                "E-mail": valores["email"],
                "Vaga": valores["vaga"],
                "Status": valores["status"],
                "_ordem": data_hora,
            }
        )

    entrevistas.sort(key=lambda entrevista: entrevista["_ordem"], reverse=True)
    for entrevista in entrevistas:
        del entrevista["_ordem"]
    return entrevistas


def main():
    if ID_DA_PLANILHA == "COLOQUE_AQUI_O_ID_DA_PLANILHA":
        raise ValueError("Preencha ID_DA_PLANILHA no início do código.")

    nome = input("Nome do candidato: ").strip()
    email = input("Email do candidato: ").strip()
    vaga = input("Vaga: ").strip()
    data = input("Data da entrevista (DD/MM/AAAA): ").strip()
    hora = input("Hora da entrevista (HH:MM): ").strip()
    duracao = int(input("Duração em minutos: ").strip())

    if not nome or not vaga:
        raise ValueError("Nome e vaga são obrigatórios.")

    if (
        email.count("@") != 1
        or any(caractere.isspace() for caractere in email)
        or not all(email.split("@"))
    ):
        raise ValueError("Informe um email válido.")

    if duracao <= 0:
        raise ValueError("A duração deve ser maior que zero.")

    # São Paulo usa UTC-03:00 atualmente.
    fuso = timezone(timedelta(hours=-3))

    inicio = datetime.strptime(
        f"{data} {hora}", "%d/%m/%Y %H:%M"
    ).replace(tzinfo=fuso)

    fim = inicio + timedelta(minutes=duracao)

    credenciais = autenticar_google()

    servico, titulo, cabecalhos, indices = preparar_planilha(
        credenciais
    )

    evento, link_meet = agendar_entrevista_com_meet(
        credenciais,
        nome,
        email,
        vaga,
        inicio,
        fim,
    )

    print("\nEvento criado:", evento.get("htmlLink", evento["id"]))

    if link_meet:
        print("Google Meet:", link_meet)
    else:
        print(
            "O evento foi criado, mas o link do Meet ainda "
            "não está disponível. Verifique o evento no calendário."
        )

    try:
        registrar_candidato_na_planilha(
            servico=servico,
            titulo_aba=titulo,
            cabecalhos=cabecalhos,
            indices=indices,
            nome=nome,
            email=email,
            vaga=vaga,
            status="Agendada",
            data_hora_inicio=inicio,
        )
    except Exception:
        print(
            "O evento já foi criado, mas o registro na planilha falhou. "
            "Registre o candidato manualmente para evitar criar "
            "outro convite ao executar novamente."
        )
        raise

    print("Candidato registrado na planilha.")


if __name__ == "__main__":
    main()