"""Interpreta pedidos dos usuaários e exceuta as ações do Google Calendar e Google Sheets."""
import json
import os   
import unicodedata
from datetime import datetime

from dotenv import load_dotenv
from openai import OpenAI
from google_tools import (
    autenticar_google,
    agendar_entrevista_com_meet,
    preparar_planilha,
    registrar_candidato_na_planilha,
)


#carregar a groq_api_key
load_dotenv()
chave_groq = os.getenv("GROQ_API_KEY")
client = (
    OpenAI(
        api_key=chave_groq,
        base_url="https://api.groq.com/openai/v1",
    )
    if chave_groq
    else None
)

MODELO_GROQ = "openai/gpt-oss-20b"
PLANILHA_ID = os.environ.get("PLANILHA_ID")

FERRAMENTAS = [
    {
        "type": "function",
        "function": {
            "name": "agendar_entrevista_com_meet",
            "description": "Agenda uma entrevista com link do Google Meet.",
            "parameters": {
                "type": "object",
                "properties": {
                    "nome_candidato": {
                        "type": "string",
                        "description": "Nome do candidato.",
                    },
                    "email_candidato": {
                        "type": "string",
                        "description": "E-mail do candidato.",
                    },
                    "vaga": {
                        "type": "string",
                        "description": "Vaga para a qual o candidato está se candidatando.",
                    },
                    "data_hora_inicio": {
                        "type": "string",
                        "description": "Data e hora de início no formato ISO 8601.",
                    },
                    "data_hora_fim": {
                        "type": "string",
                        "description": "Data e hora de término no formato ISO 8601.",
                    },
                },
                "required": [
                    "nome_candidato",
                    "email_candidato",
                    "vaga",
                    "data_hora_inicio",
                    "data_hora_fim",
                ],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "registrar_candidato_na_planilha",
            "description": "Registra os dados de um candidato na planilha do Google Sheets.",
            "parameters": {
                "type": "object",
                "properties": {
                    "nome": {
                        "type": "string",
                        "description": "Nome do candidato.",
                    },
                    "email": {
                        "type": "string",
                        "description": "E-mail do candidato.",
                    },
                    "vaga": {
                        "type": "string",
                        "description": "Vaga para a qual o candidato está se candidatando.",
                    },
                    "status": {
                        "type": "string",
                        "description": "Status atual do processo seletivo.",
                    },
                    "data_hora_inicio": {
                        "type": "string",
                        "description": (
                            "Data e hora ISO 8601 da entrevista, se conhecida; "
                            "omita para deixar data e hora em branco."
                        ),
                    },
                },
                "required": ["nome", "email"],
                "additionalProperties": False,
            },
        },
    },
]

# prompt para definior as regras do agente
PROMPT = (
    "Você é um assistente virtual especializado em processos seletivos. "
    "Ajude a coordenar entrevistas e registrar candidatos no Google Sheets. "
    "Antes de chamar uma ferramenta, confirme que todos os dados obrigatórios "
    "foram informados; nunca invente nome, e-mail, vaga, data ou horário. "
    "Ao agendar, informe data e hora ISO 8601 com fuso horário. "
    "O agendamento já registra o candidato na planilha; não chame também a "
    "ferramenta de registro para o mesmo candidato."
)

#função para normalizar ou tokenizar o texto 
def normalizar (texto):
    """Normaliza o texto removendo acentos e convertendo para minúsculas."""
    sem_acento = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in sem_acento if not unicodedata.combining(c)).lower()


def _converter_data_hora(valor):
    """Converte ISO 8601 e exige um fuso horário explícito."""
    data_hora = datetime.fromisoformat(valor.replace("Z", "+00:00"))
    if data_hora.utcoffset() is None:
        raise ValueError(
            "Informe data e hora no formato ISO 8601 com fuso horário."
        )
    return data_hora


#função para executar o agente
def executar_agente_rh(mensagem_usuario):
    """Executa o agente de RH com base na mensagem do usuário."""
    if client is None:
        return [("erro", "A chave da API do Groq não está configurada.")]

    #enviar a mensagem do usuário para o modelo Groq
    resposta = client.chat.completions.create(
        model=MODELO_GROQ,
        messages=[
            {"role": "system", "content": PROMPT},
            {"role": "user", "content": mensagem_usuario},
        ],
        tools=FERRAMENTAS,
        tool_choice="auto",
    )

    mensagem = resposta.choices[0].message
    tool_calls = mensagem.tool_calls or []
    resultados = []
    if mensagem.content:
        resultados.append(("texto", mensagem.content))

    acoes_agendamento = []
    acoes_registro = []
    for chamada in tool_calls:
        nome = chamada.function.name
        args = json.loads(chamada.function.arguments)

        if nome == "agendar_entrevista_com_meet":
            acoes_agendamento.append(
                {
                    "nome": args["nome_candidato"],
                    "email": args["email_candidato"],
                    "vaga": args["vaga"],
                    "inicio": _converter_data_hora(args["data_hora_inicio"]),
                    "fim": _converter_data_hora(args["data_hora_fim"]),
                }
            )
        elif nome == "registrar_candidato_na_planilha":
            acoes_registro.append(
                {
                    "nome": args["nome"],
                    "email": args["email"],
                    "vaga": args.get("vaga", "não informado"),
                    "status": args.get("status", "Em andamento"),
                    "inicio": (
                        _converter_data_hora(args["data_hora_inicio"])
                        if args.get("data_hora_inicio")
                        else None
                    ),
                }
            )

    if acoes_agendamento or acoes_registro:
        credenciais = autenticar_google()
        servico, titulo, cabecalhos, indices = preparar_planilha(credenciais)

        candidatos_registrados = set()
        for acao in acoes_agendamento:
            evento, link_meet = agendar_entrevista_com_meet(
                credenciais=credenciais,
                nome_candidato=acao["nome"],
                email_candidato=acao["email"],
                vaga=acao["vaga"],
                data_hora_inicio=acao["inicio"],
                data_hora_fim=acao["fim"],
            )
            detalhes = evento.get("htmlLink") or evento.get("id") or "Evento criado"
            if link_meet:
                detalhes += f" | Google Meet: {link_meet}"
            else:
                detalhes += " | Link do Meet ainda não disponível."
            resultados.append(("calendar", detalhes))

            chave_candidato = (acao["nome"].casefold(), acao["email"].casefold())
            candidatos_registrados.add(chave_candidato)
            registrar_candidato_na_planilha(
                servico=servico,
                titulo_aba=titulo,
                cabecalhos=cabecalhos,
                indices=indices,
                nome=acao["nome"],
                email=acao["email"],
                vaga=acao["vaga"],
                status="Agendada",
                data_hora_inicio=acao["inicio"],
            )
            resultados.append(
                ("planilha", f"Candidato {acao['nome']} registrado.")
            )

        for acao in acoes_registro:
            chave_candidato = (acao["nome"].casefold(), acao["email"].casefold())
            if chave_candidato in candidatos_registrados:
                continue
            registrar_candidato_na_planilha(
                servico=servico,
                titulo_aba=titulo,
                cabecalhos=cabecalhos,
                indices=indices,
                nome=acao["nome"],
                email=acao["email"],
                vaga=acao["vaga"],
                status=acao["status"],
                data_hora_inicio=acao["inicio"],
            )
            candidatos_registrados.add(chave_candidato)
            resultados.append(
                ("planilha", f"Candidato {acao['nome']} registrado.")
            )

    if not resultados:
        resultados.append(("texto", "Não foi possível identificar uma ação válida."))

    return resultados